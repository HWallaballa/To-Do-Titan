package com.javagiants.todolist.models;

public class TaskList {

}
