package com.javagiants.todolist.models;

public class MeetingTask {

}
