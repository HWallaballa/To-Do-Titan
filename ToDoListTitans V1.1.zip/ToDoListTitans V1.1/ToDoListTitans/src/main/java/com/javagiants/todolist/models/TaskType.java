package com.javagiants.todolist.models;

public enum TaskType {
    WORK,
    PERSONAL,
    SCHOOL
}
